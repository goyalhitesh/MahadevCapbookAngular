import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
answer1:string;
answer2:string;
dob:string;
emailID:string;
newPassword:string;
confirmPassword:string;
message:string;
error:string;

  constructor(private route:ActivatedRoute, private router: Router, private capbookServices: CapbookServicesService) { }

  get _emailID():string {
    return this.emailID;
}
set _emailID(value:string) {
  this.emailID = value;
}


get _answer1():string {
  return this.answer1;
}
set _answer1(value:string) {
this.answer1 = value;
}

get _answer2():string {
  return this.answer2;
}
set _answer2(value:string) {
this.answer2 = value;
}

get _dob():string {
  return this.dob;
}
set _dob(value:string) {
this.dob = value;
}

get _newPassword():string {
  return this.newPassword;
}
set _newPassword(value:string) {
this.newPassword = value;
}

get _confirmPassword():string {
  return this.confirmPassword;
}
set _confirmPassword(value:string) {
this.confirmPassword = value;
}

  ngOnInit() {
  }

  forgotPassword(){
    const user1:any={
      emailID:this._emailID,
      dob:this._dob,
      newPassword:this._newPassword,
      confirmPassword:this._confirmPassword
    }

    this.capbookServices.forgotPassword(user1).subscribe(
      message=>{
        this.message=message;
      },
      error=>{
        this.error=error;
      }
    );
  }

}
