import { Injectable } from '@angular/core';
import {Observer, Observable, throwError } from 'rxjs';
import {map, catchError} from 'rxjs/operators';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class CapbookServicesService {

  constructor(private httpClient:HttpClient) { }

  public login(user:any):Observable<void>{
   
    return this.httpClient.post<void>("http://localhost:5000/capbook/getLoginAction",user,{}).pipe(catchError(this.handleError));

  }

  public forgotPassword(user1:any):Observable<string>{
    return this.httpClient.post<string>
    ("--------------------",user1,{}).pipe(catchError(this.handleError));
  }

  private handleError(error: any) {
    if (error instanceof ErrorEvent) {
      console.error(`1 An ErrorEvent occurred: `, error.error.message);
      return throwError(error.error.message);
    } else if (error instanceof HttpErrorResponse) {
      console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
      return throwError(`Backend returned code ${error.status}, body was: ${error.message}`);
    } else if (error instanceof TypeError) {
      console.error(`3 TypeError has occured ${error.message}, body was: ${error.stack}`);
      return throwError(`TypeError has occured ${error.message}, body was: ${error.stack}`);
    }
  }
}
