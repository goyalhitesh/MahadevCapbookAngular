import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpEventType } from '@angular/common/http';


@Component({
  selector: 'app-album',
  templateUrl: './album.component.html',
  styleUrls: ['./album.component.css']
})
export class AlbumComponent implements OnInit {
  // imageUrl:string="/assets/images/img11.png";
  // fileToUpload:File=null;

  selectedFile: File =null;

  constructor(private http: HttpClient) { }
  // handleFileInput(file:FileList){
  // this.fileToUpload=file.item(0);
  // var reader=new FileReader();
  // reader.onload=(event:any)=>{
  //   this.imageUrl = event.target.result;
  // }
  // reader.readAsDataURL(this.fileToUpload);
  // }

  onFileSelected(event){
    this.selectedFile=<File>event.target.files[0];
  }

  onUpload(){
    const fd = new FormData();
    fd.append('image',this.selectedFile,this.selectedFile.name);
    this.http.post('',fd,{
      reportProgress:true,
      observe:'events'
    })
   
    .subscribe(event=> {
      if(event.type===HttpEventType.UploadProgress){
        console.log('Upload progress: '+ Math.round(event.loaded/ event.total*100)+'%')
      } else if(event.type===HttpEventType.Response){
        console.log(event);
      }
    });
  }

  ngOnInit() {
  }

}
